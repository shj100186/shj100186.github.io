# Change Log

## [0.9.6] - 2022/03/17

### CHANGED

- share local authentication context(https://github.com/lyokato/WebAuthnKit-iOS/pull/17). thanks to JaapWijnen

