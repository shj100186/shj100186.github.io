//
//  WebAuthnKit.h
//  WebAuthnKit
//
//  Created by Lyo Kato on 2018/11/20.
//  Copyright © 2018 Lyo Kato. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WebAuthnKit.
FOUNDATION_EXPORT double WebAuthnKitVersionNumber;

//! Project version string for WebAuthnKit.
FOUNDATION_EXPORT const unsigned char WebAuthnKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WebAuthnKit/PublicHeader.h>


