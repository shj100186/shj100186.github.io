Interop with https://github.com/ritou/elixir-web_authn_lite

The gist is here.

https://gist.github.com/ritou/186cefb7f2767d06e4e32c7935be8a0b
